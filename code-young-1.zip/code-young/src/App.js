import React, {useEffect, useState} from 'react'
import GoogleLogin from 'react-google-login'
import './App.css'
import {BrowserRouter as Router, Route} from "react-router-dom"
import CurrrencyRow from './components/CurrrencyRow'


const Base_url = 'https://api.exchangeratesapi.io/latest'
 
 
function App() {
   const [currencyoptions, setCurrencyOptions] = useState([])
   const [fromcurrency, setFromCurrency] = useState()
   const  [tocurrency, setToCurrency] = useState() 
   const [exchangerate, setExchangerate] =  useState()
   const [amount, setAmount] = useState(1)
   const [amountinfromcurrency, setAmountInFromCurrency] = useState(true)
   
    let toamount, fromamount;
    
    if(amountinfromcurrency){
      fromamount = amount
      toamount = amount * exchangerate
    }
    else{
      toamount = amount
      fromamount = amount / exchangerate
    }

       useEffect(() =>{
         fetch(Base_url)
         .then(Response=> Response.json())
         .then(data => {
           const firstCurrency = Object.keys(data.rates)[0]
            setCurrencyOptions([data.base, ...Object.keys(data.rates)])
            setFromCurrency(data.base)
            setToCurrency(firstCurrency)
            setExchangerate(data.rates[firstCurrency])
         })
       }, [])

       useEffect(()=>{
         if(fromcurrency != null & tocurrency != null){
           fetch(`${Base_url}?base=${fromcurrency}&symbols=${tocurrency}`)
           .then(res=> res.json())
           .then(data=> setExchangerate(data.rates[tocurrency]))
         }
       },[fromcurrency, tocurrency])
     
    const handleFromAmountChange = (e) =>{
         setAmount(e.target.value)
         setAmountInFromCurrency(true)
       }

     const handleToAmountChange = (e) =>{
        setAmount(e.target.value)
        setAmountInFromCurrency(false)
      }
     
      // responseGoogle = (response)=>{
      //   console.log(response);
      //   console.log(response.profileobj);
      // }

  return (
    <div>
    {/* <GoogleLogin
      clientId="503033855798-6o3r4g99qvhsts183plbt2s0368ddf89.apps.googleusercontent.com"
      buttonText="Login"
      onSuccess={this.responseGoogle}
      onFailure={this.responseGoogle}
      cookiePolicy={'single_host_origin'}
    /> */}
    
        <div className="card">
              <h2>Currency converter</h2>
              <CurrrencyRow
                currencyoptions ={currencyoptions}
                selectedcurrency ={fromcurrency}
                onChangecurrency={e => setFromCurrency(e.target.value)}
                amount = {fromamount}
                onchangeamount={handleFromAmountChange}
              />
              <div className="equal">=</div>
              <CurrrencyRow
                currencyoptions ={currencyoptions}
                selectedcurrency ={tocurrency}
                onChangecurrency={e => setToCurrency(e.target.value)}
                amount = {toamount}
                onchangeamount={handleToAmountChange}
              />
         </div>
    </div>
  )
}

export default App
