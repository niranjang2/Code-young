import React from 'react'

export default function CurrrencyRow(props) {

    const { currencyoptions, selectedcurrency, onChangecurrency, amount, onchangeamount } = props
    return (
        <div>
            <input className="input" type="number" value={amount} onChange={onchangeamount} />
            <select value={selectedcurrency} onChange={onChangecurrency}>
            {currencyoptions.map(option =>(
                <option key={option} value={option}>{option}</option>
            ))}
                
            </select>
        </div>
    )
}
